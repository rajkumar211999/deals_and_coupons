package com.dealsandcouponsfinder.profilemanagement.repository;

import org.springframework.data.repository.CrudRepository;

import com.dealsandcouponsfinder.profilemanagement.model.Profile;

public interface ProfileRepository extends CrudRepository<Profile, String>{

}

