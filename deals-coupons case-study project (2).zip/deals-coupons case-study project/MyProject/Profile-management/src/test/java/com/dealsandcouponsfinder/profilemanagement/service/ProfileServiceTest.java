package com.dealsandcouponsfinder.profilemanagement.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.dealsandcouponsfinder.profilemanagement.exception.ProfileRequestException;
import com.dealsandcouponsfinder.profilemanagement.model.Credentials;
import com.dealsandcouponsfinder.profilemanagement.model.Profile;
import com.dealsandcouponsfinder.profilemanagement.repository.CredentialsRepository;
import com.dealsandcouponsfinder.profilemanagement.repository.ProfileRepository;

@SpringBootTest
public class ProfileServiceTest {

	@Autowired
	ProfileService profileService;

	@MockBean
	private ProfileRepository profileRepository;
	@MockBean
	private CredentialsRepository credentialsRepository;

	@Test
	void saveTest() {
		Profile pro = new Profile("vrk143@gmail.com", "Rajkumar", "8919825544", "Beverage");
		when(profileRepository.save(pro)).thenReturn(pro);
		assertEquals(pro, profileService.save(pro));
	}
	
	@Test 
	 public void deleteByIdTest() throws ProfileRequestException {
		when (profileRepository.findById("vrk143@gmail.com")).thenReturn(Optional.of(new Profile("vrk143@gmail.com", "rajkumar", "8919825544", "Beverage")));
		doNothing().when(profileRepository).deleteById("vrk143@gmail.com");
		assertEquals(profileService.deleteById("vrk143@gmail.com"), "Id vrk143@gmail.com deleted!");
	}	
	
	@Test
	public void findByIdTest() throws ProfileRequestException {
		when (profileRepository.findById("vrk143@gmail.com")).thenReturn(Optional.of(new Profile("vrk143@gmail.com", "rajkumar", "8919825544", "Beverage")));
		Optional<Profile> profile = profileService.findById("vrk143@gmail.com");
		assertEquals("vrk143@gmail.com",profile.get().getEmailId());
		assertEquals("rajkumar",profile.get().getFullName());
		assertEquals("8919825544",profile.get().getMobileNo());
		
		
	}

	
}
